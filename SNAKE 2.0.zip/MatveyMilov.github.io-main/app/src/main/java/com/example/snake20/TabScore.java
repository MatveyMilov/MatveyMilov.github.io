package com.example.snake20;


import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;

public class TabScore {
    private final String SETTINGS = "settings";
    public static final String APP_PREFERENCES_SCORE = "score";
    SharedPreferences mSettings;

}