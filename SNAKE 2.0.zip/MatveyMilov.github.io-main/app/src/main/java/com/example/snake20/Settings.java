package com.example.snake20;

import android.content.SharedPreferences;

public class Settings {
    public final String SETTINGS = "settings";
    public static final String APP_PREFERENCES_SCORE = "score";


}
